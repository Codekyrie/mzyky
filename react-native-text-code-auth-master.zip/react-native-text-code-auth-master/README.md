# Firebase Text Code Auth
The purpose of this little test app is to have a Sign Up form which takes a unique phone number and registers them as a user on Google's Firebase.

Then, the Sign In form takes that phone number and texts the user a random code that they will use to authenticate their login.  

I used Twilio to setup the text, Google Cloud Functions to setup the API without having to build an entire server, and Firebase to handle the databse and authentification!

## Running
Built using Expo which sadly no longer works with a QR reader.  Will upload a gif of the app in action later.